=== Illdy ===

Contributors: Colorlib
Tags: blog, e-commerce, education, entertainment, news, food-and-drink, holiday, photography, portfolio

Requires at least: 4.0
Tested up to: 4.7.2
Stable tag: 2.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Illdy is a free premium one page WordPress theme.

== Installation ==
	
1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

= License =
Illdy WordPress theme, Copyright (C) 2015 Colorlib.com
Illdy WordPress theme is licensed under the GPL3.

Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public License.
The exceptions to this license are as follows:

* Bootstrap v3.3.6 (http://getbootstrap.com):
    Copyright 2011-2014 Twitter, Inc.
    Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)

* Images:
	All images are from Unsplash (	www.unsplash.com	) and Pixabay( www.pixabay.com	)
	License under Creative Commons Zero.


	https://pixabay.com/en/bed-bedroom-door-girl-house-1850893/


	Sources for images used:
		https://unsplash.com/photos/VviFtDJakYk
		https://unsplash.com/photos/hoCXpPUMCoE
		https://pixabay.com/en/coffee­tablet­headphones­work­1128140/
		https://unsplash.com/photos/T0bQdp74I0U
		https://unsplash.com/photos/VLT62­JzddA
		https://pixabay.com/en/turntable­top­view­audio­equipment­1109588/
		https://pixabay.com/en/computer­apple­imac­keyboard­mouse­791392/
		https://pixabay.com/en/man­reading­touchscreen­blog­791049/
		https://pixabay.com/en/workspace­place­of­work­work­766045/
		https://pixabay.com/en/coffee­coffe­latte­516186/
		https://unsplash.com/photos/zCevd81eJDU
		https://unsplash.com/photos/2UE1givDiPM
		https://unsplash.com/photos/lZlfHGqx44Q
		https://unsplash.com/photos/71cd1rWqO8M
		https://unsplash.com/photos/HALe2SmkWAI
		https://unsplash.com/photos/hiAdjnXZxl8
		https://unsplash.com/photos/eqsEZNCm4­c
		https://pixabay.com/en/fashion­beauty­model­portrait­girl­1063100/
		https://pixabay.com/en/home­office­notebook­home­couch­569153/
		https://pixabay.com/en/adult-beach-enjoyment-1867618/
		https://stocksnap.io/photo/7LQZXYOHL9
		https://stocksnap.io/photo/PLFB4I53U4
		https://stocksnap.io/photo/D3WN2GEYA3
		https://pixabay.com/en/canine-cute-dog-footwear-hammock-1851504/

* Font Awesome:
	License: SIL OFL 1.1
	URL: http://scripts.sil.org/OFL

* Google Fonts:
	Source Sans Pro (https://www.google.com/fonts/specimen/Source+Sans+Pro)
	License under SIL Open Font License, 1.1
	Copyright © Paul D. Hunt (https://plus.google.com/108888178732927400671/about)

* owl-carousel.js (http://www.owlcarousel.owlgraphic.com/):
	Copyright 2013 Bartosz Wojciechowski
	License under The MIT License (MIT)

* count-to.js (https://github.com/mhuggins/jquery-countTo):
	Copyright Matt Huggins
	License under MIT license.
